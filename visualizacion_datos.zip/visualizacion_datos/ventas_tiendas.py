import matplotlib.pyplot as plt

#Datos
meses = ["Ene", "Feb", "Mar", "Abr", "May"]
ventas = [10, 15, 12, 20, 25]

#Crear gráfica
plt.plot(meses, ventas, marker="o")

#Títulos
plt.title("Ventas de la tienda")
plt.xlabel("Mes")
plt.ylabel("Ventas")

#Mostrar
plt.show()