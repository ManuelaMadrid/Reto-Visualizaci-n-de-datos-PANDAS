import matplotlib.pyplot as plt
import seaborn as sns

productos = ["Laptop", "Monitor", "Mouse", "Teclado", "Audífonos"]
ventas = [25, 18, 40, 30, 22]

sns.barplot(x=productos, y=ventas, hue=productos, palette="viridis", legend=False)

plt.title("Ventas por producto (Seaborn)")
plt.xlabel("Producto")
plt.ylabel("Unidades vendidas")
plt.show()