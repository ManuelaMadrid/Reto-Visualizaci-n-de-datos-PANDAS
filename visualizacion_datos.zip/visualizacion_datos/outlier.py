import matplotlib.pyplot as plt

datos = [10, 12, 11, 13, 12, 95]

plt.plot(datos, marker="o")

plt.title("Detectando un outlier")
plt.xlabel("Posición del dato")
plt.ylabel("Valor")

plt.show()