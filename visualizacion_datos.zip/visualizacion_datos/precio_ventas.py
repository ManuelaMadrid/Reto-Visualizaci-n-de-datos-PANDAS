import matplotlib.pyplot as plt

# Datos (precio en miles de pesos, unidades vendidas)
precio = [90, 150, 320, 850, 1200, 2500]
ventas = [40, 30, 22, 18, 12, 6]

# Crear gráfica
plt.scatter(precio, ventas)

# Títulos
plt.title("Relación entre precio y ventas")
plt.xlabel("Precio (miles de pesos)")
plt.ylabel("Unidades vendidas")

# Mostrar
plt.show()