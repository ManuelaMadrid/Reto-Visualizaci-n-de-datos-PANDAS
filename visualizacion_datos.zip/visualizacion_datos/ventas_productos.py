import matplotlib.pyplot as plt

# Datos
productos = ["Laptop", "Monitor", "Mouse", "Teclado", "Audífonos"]
ventas = [25, 18, 40, 30, 22]

# Crear gráfica
plt.bar(productos, ventas)

# Títulos
plt.title("Ventas por producto")
plt.xlabel("Producto")
plt.ylabel("Unidades vendidas")

# Mostrar
plt.show()